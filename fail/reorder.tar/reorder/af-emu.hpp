#include <CL/sycl.hpp>
// #include <arrayfire.h>
#include <stdlib.h>

#define ONEAPI_DEBUG_FINISH(Q) Q.wait_and_throw()

#define divup(a, b) (((a) + (b)-1) / (b))

typedef unsigned char uchar;

typedef long long dim_t;

typedef struct {
    dim_t dims[4];
    dim_t strides[4];
    dim_t offset;
} KParam;

template<typename T>
struct Param {
  sycl::buffer<T> *data;
  KParam info;
};

sycl::queue getQueue() {
    return sycl::queue();
}

Param<float> create_param(size_t dims0, size_t dims1 = 1, size_t dims2 = 1, size_t dims3 = 1) {
    Param<float> out;
    out.info.dims[0] = dims0;
    out.info.dims[1] = dims1;
    out.info.dims[2] = dims2;
    out.info.dims[3] = dims3;
    out.info.strides[0] = 1;
    out.info.strides[1] = out.info.strides[0] * out.info.dims[0];
    out.info.strides[2] = out.info.strides[1] * out.info.dims[1];
    out.info.strides[3] = out.info.strides[2] * out.info.dims[2];
    out.info.offset = 0;
    out.data = new sycl::buffer<float, 1>{sycl::range{dims0 * dims1 * dims2 * dims3}};
    return out;
}
Param<float> create_param(float *in, size_t dims0, size_t dims1 = 1, size_t dims2 = 1,
                          size_t dims3 = 1) {
  auto out = create_param(dims0, dims1, dims2, dims3);
  const sycl::host_accessor<float> out_data(*out.data);
  const int nelems = dims0 * dims1 * dims2 * dims3;
  for (int i = 0; i < nelems; i++) out_data[i] = in[i];
  return out;
}
#define P create_param

using cdouble = std::complex<double>;
using cfloat  = std::complex<float>;

unsigned nextpow2(unsigned x) {
    x = x - 1U;
    x = x | (x >> 1U);
    x = x | (x >> 2U);
    x = x | (x >> 4U);
    x = x | (x >> 8U);
    x = x | (x >> 16U);
    return x + 1U;
}
