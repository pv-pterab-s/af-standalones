#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#define DO_NOT_WRITE
#include "rotate.hpp"

int main(int argc, char **argv) {
    // Param<float> out; Param<float> in; float theta; af_interp_type method; int order;
    // OPEN_R("/home/gpryor/new-dev/data/test-00");
    // READ(out); READ(in); READ(theta); READ(method); READ(order);
    // for (int i = 0; i < 1; i++)
    //   oneapi::kernel::rotate(out, in, theta, method, order);

    // does just creating something on our own cause a crash? (eventually)
    // const int dims0 = 45, dims1 = 45;
    const int dims0 = 10, dims1 = 10;
    float theta; af_interp_type method; int order;
    float *host_input = (float *)malloc(sizeof(float) * dims0 * dims1);
    auto in = P(host_input, dims0, dims1);
    auto out = P(dims0, dims1);
    theta = 0.0; method = AF_INTERP_NEAREST; order = 1;
    for (int i = 0; i < 5; i++)
      oneapi::kernel::rotate(out, in, theta, method, order);

    // // Param<float> out; Param<float> in; float theta; af_interp_type method; int order;
    // float host_input[] = {1, 2, 3, 1, 2, 3, 1, 2, 3};
    // auto input = P(host_input, 3, 3);
    // auto output = P(3, 3);
    // M(theta); M(order);
    // // theta = 0.8;
    // for (int i = 0; i < 10; i++)
    //   oneapi::kernel::rotate(output, input, theta, method, order);
    // // M(input);
    // // M(output);
}
