#define ONEAPI_DEBUG_FINISH(Q) Q.wait_and_throw()
