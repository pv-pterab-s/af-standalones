# ./out/main Segfaults

Build `./out/main` assuming OneAPI default location:

    source /opt/intel/oneapi/setvars.sh intel64
    make
    ./out/main

1. `./out/main` will segfault 47% of the time.
2. This is what it looks like ...

        corrupted size vs. prev_size
        Aborted (core dumped)
        free(): invalid pointer
        Aborted (core dumped)
        free(): invalid pointer
        Aborted (core dumped)
        free(): invalid pointer
        Aborted (core dumped)
        terminate called after throwing an instance of 'cl::sycl::runtime_error'
          what():  Native API failed. Native API returns: -38 (CL_INVALID_MEM_OBJECT) -38 (CL_INVALID_MEM_OBJECT)
        Aborted (core dumped)

Happens on:

  - Ubuntu 22.04. Ryzen AMD Ryzen 9 3900X 12-Core Processor
  - Backend is`SYCL host platform: SYCL host device, 32029 MB -- 1.2 -- Device driver 1.2 --
FP64 Support: True -- Unified Memory (True)`.

  - OneAPI says its version is:

        Intel(R) oneAPI DPC++/C++ Compiler 2022.2.0 (2022.2.0.20220730)
        Target: x86_64-unknown-linux-gnu
        Thread model: posix
        InstalledDir: /opt/intel/oneapi/compiler/2022.2.0/linux/bin-llvm
        Configuration file: /opt/intel/oneapi/compiler/2022.2.0/linux/bin/icpx.cfg
