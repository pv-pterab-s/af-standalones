#pragma once
#include <af/defines.h>

namespace af {

  template<typename T> struct dtype_traits;

  template<>
  struct dtype_traits<float> {
    enum {
      af_type = f32,
      ctype = f32
    };
    typedef float base_type;
    static const char* getName() { return "float"; }
  };

  template<>
  struct dtype_traits<int> {
    enum {
      af_type = s32 ,
      ctype = f32
    };
    typedef int base_type;
    static const char* getName() { return "int"; }
  };

}  // namespace af
