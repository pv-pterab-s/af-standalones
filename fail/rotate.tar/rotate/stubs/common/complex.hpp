#pragma once
#include <types.hpp>

namespace common {

// The value returns true if the type is a complex type. False otherwise
template<typename T>
struct is_complex {
    static const bool value = false;
};
template<>
struct is_complex<cfloat> {
    static const bool value = true;
};
template<>
struct is_complex<cdouble> {
    static const bool value = true;
};

}  // namespace common
