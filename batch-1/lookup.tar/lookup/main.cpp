#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "lookup.hpp"

namespace oneapi {
namespace kernel {
template
void lookup<float,int>(Param<float> out, const Param<float> in, const Param<int> indices,
            const unsigned dim);
}
}

int main(int argc, char **argv) {
    M("HEY");
    return 0;
}
