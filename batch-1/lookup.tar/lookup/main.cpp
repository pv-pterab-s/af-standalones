#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "lookup.hpp"

namespace arrayfire {
namespace oneapi {
namespace kernel {
template void lookup<float, int>(Param<float> out, const Param<float> in,
                                 const Param<int> indices, const unsigned dim);
}
} // namespace oneapi
} // namespace arrayfire

int main(int argc, char **argv) {
    return 0;
}
