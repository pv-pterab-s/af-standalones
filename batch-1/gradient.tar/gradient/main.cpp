#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "gradient.hpp"

// at least one instantiation around to catch errors
namespace oneapi {
  namespace kernel {
    void gradient(Param<std::complex<double>> grad0, Param<std::complex<double>> grad1, const Param<std::complex<double>> in);
    void gradient(Param<float> grad0, Param<float> grad1, const Param<float> in);
  }
}

int main(int argc, char **argv) {
    M("HEY");
    return 0;
}
