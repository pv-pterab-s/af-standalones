#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "tile.hpp"

namespace oneapi {
namespace kernel {

template void tile<float>(Param<float> out, const Param<float> in);
}
}

int main(int argc, char **argv) {
    M("HEY");
    return 0;
}
