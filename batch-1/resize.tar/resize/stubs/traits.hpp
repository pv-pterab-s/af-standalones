#include <common/traits.hpp>

using af::dtype_traits;
