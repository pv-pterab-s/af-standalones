#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"
#include <types.hpp>
#include <vector>

namespace detail = oneapi;

#include "approx1.hpp"

int main(int argc, char **argv) {
    // must run on arc
    auto device = cl::sycl::default_selector().select_device();
    auto device_name = device.get_info<cl::sycl::info::device::name>();
    auto platform_name = device.get_platform().get_info<sycl::info::platform::name>();
    assert(device_name.substr(0, 17) == "Intel(R) Graphics" && platform_name == "Intel(R) Level-Zero");

    OPEN_R("data/approx1");
    Param<float> yo; Param<float> yi; Param<float> xo; int xdim; float xi_beg; float xi_step; float offGrid; af_interp_type method; int order;
    READ(yo); READ(yi); READ(xo); READ(xdim); READ(xi_beg); READ(xi_step); READ(offGrid); READ(method); READ(order);

    printf("doing nearest neighbor approx1\n");
    arrayfire::oneapi::kernel::approx1<float, float, 1>(yo, yi, xo, xdim, xi_beg, xi_step,
                                             offGrid, method);

    printf("doing linear interpolation approx1\n");
    arrayfire::oneapi::kernel::approx1<float, float, 2>(yo, yi, xo, xdim, xi_beg, xi_step,
                                             offGrid, method);

    return 0;
}
