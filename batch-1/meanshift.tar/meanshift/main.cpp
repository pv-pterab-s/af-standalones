#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "meanshift.hpp"

namespace oneapi {
namespace kernel {
template void meanshift<float>(Param<float> out, const Param<float> in,
                               const float spatialSigma,
                               const float chromaticSigma, const uint numIters,
                               const bool is_color);
}
}

int main(int argc, char **argv) {
    // somehow pull tests and run them
    // this process is incredibly slow
    return 0;
}
