#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "select.hpp"

namespace oneapi {
namespace kernel {
  template
void selectLauncher(Param<float> out, Param<char> cond, Param<float> a, Param<float> b, const int ndims,
                    const bool is_same);
  template
void select_scalar(Param<float> out, Param<char> cond, Param<float> a, const float b, const int ndims,
                   const bool flip);
}
}

int main(int argc, char **argv) {
    M("HEY");
    return 0;
}
