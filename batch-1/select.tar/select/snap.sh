#!/bin/bash
# -*- compile-command: "./snap.sh lookup"; -*-
set -e

if [ -z "$1" ]; then
    echo usage: snap.sh FUNCTION_NAME
    exit 1
fi

if [ -f "../$1.tar" ]; then
    echo ../$1.tar already exists
    exit 1
fi

rm -rf out
THIS_DIR="$(basename $(pwd))"
cd ..
tar --exclude="$THIS_DIR/.git" --exclude="$THIS_DIR/.ccls-cache" -hc $THIS_DIR > "$1.tar"
