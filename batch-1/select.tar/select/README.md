Just in case you forget, this is the repo that allows porting opencl to oneapi
as a standalone exercise.

By symlinking the target oneapi header in arrayfire, the port will compile
here and inside arrayfire.

Once the function is complete, run snap to create a tar to record in the
`af-standalones` github repo.
