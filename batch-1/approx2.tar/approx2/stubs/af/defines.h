#pragma once

#define AF_API_VERSION 34

typedef enum {
    AF_INTERP_NEAREST,         ///< Nearest Interpolation
    AF_INTERP_LINEAR,          ///< Linear Interpolation
    AF_INTERP_BILINEAR,        ///< Bilinear Interpolation
    AF_INTERP_CUBIC,           ///< Cubic Interpolation
    AF_INTERP_LOWER           ///< Floor Indexed
#if AF_API_VERSION >= 34
    , AF_INTERP_LINEAR_COSINE   ///< Linear Interpolation with cosine smoothing
#endif
#if AF_API_VERSION >= 34
    , AF_INTERP_BILINEAR_COSINE ///< Bilinear Interpolation with cosine smoothing
#endif
#if AF_API_VERSION >= 34
    , AF_INTERP_BICUBIC         ///< Bicubic Interpolation
#endif
#if AF_API_VERSION >= 34
    , AF_INTERP_CUBIC_SPLINE    ///< Cubic Interpolation with Catmull-Rom splines
#endif
#if AF_API_VERSION >= 34
    , AF_INTERP_BICUBIC_SPLINE  ///< Bicubic Interpolation with Catmull-Rom splines
#endif

} af_interp_type;

typedef enum {
    f32,    ///< 32-bit floating point values
    c32,    ///< 32-bit complex floating point values
    f64,    ///< 64-bit floating point values
    c64,    ///< 64-bit complex floating point values
    b8 ,    ///< 8-bit boolean values
    s32,    ///< 32-bit signed integral values
    u32,    ///< 32-bit unsigned integral values
    u8 ,    ///< 8-bit unsigned integral values
    s64,    ///< 64-bit signed integral values
    u64    ///< 64-bit unsigned integral values
    , s16    ///< 16-bit signed integral values
    , u16    ///< 16-bit unsigned integral values
    , f16    ///< 16-bit floating point value
} af_dtype;

namespace af {
  typedef af_dtype dtype;
  typedef af_interp_type interpType;
}
