#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"
#include <types.hpp>
#include <vector>

namespace detail = oneapi;

#include "approx2.hpp"

int main(int argc, char **argv) {
    // must run on arc
    auto device = cl::sycl::default_selector().select_device();
    auto device_name = device.get_info<cl::sycl::info::device::name>();
    auto platform_name = device.get_platform().get_info<sycl::info::platform::name>();
    assert(device_name.substr(0, 17) == "Intel(R) Graphics" && platform_name == "Intel(R) Level-Zero");

Param<float> zo;
 Param<float> zi;
 Param<float> xo;
             int xdim;
 float xi_beg;
 float xi_step;
             Param<float> yo;
 int ydim;
 float yi_beg;
             float yi_step;
 float offGrid;
 af_interp_type method;

  OPEN_R("data/approx2");
    READ(zo); READ(zi); READ(xo); READ(xdim); READ(xi_beg); READ(xi_step); READ(yo); READ(ydim); READ(yi_beg); READ(yi_step); READ(offGrid); READ(method);

    printf("doing nearest neighbor approx2\n");
    oneapi::kernel::approx2<float, float, 1>(zo, zi, xo, xdim, xi_beg, xi_step,
                                             yo, ydim, yi_beg, yi_step, offGrid,
                                             method);

    printf("doing linear interpolation approx2\n");
    oneapi::kernel::approx2<float, float, 2>(zo, zi, xo, xdim, xi_beg, xi_step,
                                             yo, ydim, yi_beg, yi_step, offGrid,
                                             method);

    return 0;
}
