// #define ONEAPI_DEBUG_FINISH(Q)                                  \
//   do {                                                          \
//     if (oneapi::synchronize_calls()) { Q.wait_and_throw(); }    \
//   } while (false);
