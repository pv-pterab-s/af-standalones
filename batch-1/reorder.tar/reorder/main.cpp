#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"
#include <types.hpp>
#include <vector>

namespace detail = oneapi;

#include "reorder.hpp"

namespace oneapi {
namespace kernel {

// template
// void resize<>(Param<float> out, const Param<float> in, const af_interp_type method);

}
}

int main(int argc, char **argv) {
    OPEN_R("data/reorder");
    Param<float> out; Param<float> in; dim_t rdims[4];
    READ(out); READ(in); READ(rdims[0]); READ(rdims[1]); READ(rdims[2]); READ(rdims[3]);

    // must run on arc
    auto device = cl::sycl::default_selector().select_device();
    auto device_name = device.get_info<cl::sycl::info::device::name>();
    auto platform_name = device.get_platform().get_info<sycl::info::platform::name>();
    assert(device_name.substr(0, 17) == "Intel(R) Graphics" &&
           platform_name == "Intel(R) Level-Zero");

    M("executing reorder");
    arrayfire::oneapi::kernel::reorder(out, in, rdims);
    M("complete");

    return 0;
}
