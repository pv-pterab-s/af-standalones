#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "impl.hpp"

int main(int argc, char **argv) {
    Param<float> out; Param<float> in; dim_t wx; dim_t wy;
    dim_t sx; dim_t sy; dim_t px; dim_t py;
    dim_t dx; dim_t dy; dim_t nx;
    bool is_column;
    OPEN_R("data/test-00");
    READ(out); READ(in); READ(wx); READ(wy); READ(sx); READ(sy); READ(px); READ(py); READ(dx); READ(dy); READ(nx); READ(is_column);
    oneapi::kernel::unwrap(out, in, wx, wy, sx, sy, px, py, dx, dy, nx, is_column);
    getQueue().wait();
    M("ran");
}
