#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "convolve.hpp"

int main(int argc, char **argv) {
    M("ran");
}
