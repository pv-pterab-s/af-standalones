#!/bin/bash
# -*- compile-command: "./snap.sh rotate"; -*-
set -e

if [ -z "$1" ]; then echo usage: snap.sh FUNCTION_NAME; exit 1; fi

mkdir -p out
OUT_DIR=$(readlink -f out)

DEST_DIR="$(mktemp -d)"
mkdir $DEST_DIR/$1
rm -rf /tmp/$1
tar --exclude=".git" --exclude=".ccls-cache" --exclude="out" --exclude=".dir-locals.el" -hc . | (cd $DEST_DIR/$1 && tar x)

cd $DEST_DIR && tar c $1 > $OUT_DIR/$1.tar
