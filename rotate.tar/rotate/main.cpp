#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"
#include <types.hpp>
#include <vector>

namespace detail = oneapi;

#include "rotate.hpp"

namespace oneapi {
namespace kernel {

template
void rotate(Param<float> out, const Param<float> in, const float theta, af_interp_type method, int order);

}
}

int main(int argc, char **argv) {
    OPEN_R("data/rot");
    Param<float> out; Param<float> in; float theta; af_interp_type method; int order;
    READ(out); READ(in); READ(theta); READ(method); READ(order);

    // must run on arc
    auto device = cl::sycl::default_selector().select_device();
    auto device_name = device.get_info<cl::sycl::info::device::name>();
    auto platform_name = device.get_platform().get_info<sycl::info::platform::name>();
    assert(device_name.substr(0, 17) == "Intel(R) Graphics" &&
           platform_name == "Intel(R) Level-Zero");

    M("executing rotate");
    oneapi::kernel::rotate(out, in, theta, method, order);
    M("complete");

    return 0;
}
