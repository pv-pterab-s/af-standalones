#pragma once

template<typename T>
static T scalar(double val) {
    return (T)(val);
}

template<>
inline cfloat scalar<cfloat>(double val) {
    cfloat cval(static_cast<float>(val));
    // cval.real() = (float)val;
    // cval.imag() = 0;
    return cval;
}

template<>
inline cdouble scalar<cdouble>(double val) {
    cdouble cval(val);
    return cval;
}

template<typename To, typename Ti>
static To scalar(Ti real, Ti imag) {
    To cval(real, imag);
    return cval;
}
