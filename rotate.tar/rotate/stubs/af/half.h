#pragma once

typedef struct {
    union {
        unsigned short data_ : 16;
        struct {
            unsigned short fraction : 10;
            unsigned short exponent : 5;
            unsigned short sign : 1;
        };
    };
} af_half;

namespace af {
typedef af_half half;
}
