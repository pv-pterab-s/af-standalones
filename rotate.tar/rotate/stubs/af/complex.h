namespace af{

typedef struct af_cfloat {
    float real;
    float imag;
    af_cfloat(const float _real = 0, const float _imag = 0) :real(_real), imag(_imag) {}
} af_cfloat;

typedef struct af_cdouble {
    double real;
    double imag;
    af_cdouble(const double _real = 0, const double _imag = 0) :real(_real), imag(_imag) {}
} af_cdouble;

typedef af::af_cfloat   cfloat;
typedef af::af_cdouble  cdouble;

}
