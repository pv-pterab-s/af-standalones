#!/bin/bash
# -*- compile-command: "./snap.sh"; -*-
set -e

rm -rf out
cd ..
tar --exclude="new-dev/.git" --exclude="new-dev/.ccls-cache" -hc new-dev > new-dev.tar
