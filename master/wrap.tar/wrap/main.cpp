#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"

#include "wrap.hpp"
#include "wrap_dilated.hpp"

// at least one instantiation around to catch errors
namespace arrayfire {
namespace oneapi {
namespace kernel {

template void wrap(Param<float> out, const Param<float> in, const dim_t wx,
                   const dim_t wy, const dim_t sx, const dim_t sy,
                   const dim_t px, const dim_t py, const bool is_column);
template void wrap_dilated(Param<float> out, const Param<float> in,
                           const dim_t wx, const dim_t wy, const dim_t sx,
                           const dim_t sy, const dim_t px, const dim_t py,
                           const dim_t dx, const dim_t dy,
                           const bool is_column);
} // namespace kernel
} // namespace oneapi
} // namespace arrayfire

int main(int argc, char **argv) {
    return 0;
}
