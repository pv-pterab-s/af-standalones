#include "af-emu.hpp"
#include "msg.hpp"
#include "io.hpp"
#include "convolve.hpp"

int main(int argc, char **argv) {
    Param<float> out; Param<float> signal; Param<float> filter;
    AF_BATCH_KIND kind; int rank; bool expand;
    OPEN_R("data/convolve");
    READ(out); READ(signal); READ(filter); READ(kind); READ(rank); READ(expand);

    oneapi::kernel::convolve_nd(out, signal, filter, kind, rank, expand);
}
